package cecilia.rios.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var valor:Double=0.0
    var val1:String=""
    var val2:String=""
    var operacion:Int=0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_0.setOnClickListener{
            num(0)
        }

        btn_1.setOnClickListener {
            num(1)
        }

        btn_2.setOnClickListener {
            num(2)
        }

        btn_3.setOnClickListener {
            num(3)
        }

        btn_4.setOnClickListener {
            num(4)
        }

        btn_5.setOnClickListener {
            num(5)
        }

        btn_6.setOnClickListener {
            num(6)
        }

        btn_7.setOnClickListener {
            num(7)
        }

        btn_8.setOnClickListener {
            num(8)
        }

        btn_9.setOnClickListener {
            num(9)
        }

        btn_multiplicar.setOnClickListener(){
            operacion(1)
        }

        btn_dividir.setOnClickListener(){
            operacion(2)
        }

        btn_restar.setOnClickListener(){
            operacion(3)
        }

        btn_suma.setOnClickListener(){
            operacion(4)
        }

        btn_borrar.setOnClickListener(){
            operacion(5)
        }

        btn_resultado.setOnClickListener(){
            operacion(6)
        }


    }


    fun operacion(op: Int){

        when(op){

            1->{
                operacion=1
                if(val2!=""){
                    val1=val2
                    valor1.text=val1
                    val2=""
                    valor2.text="0"
                    signo.text="*"
                }
                /*
                if(valor==0.0){
                    valor+=resultado.text.toString().toDouble()
                }else{
                    valor*=resultado.text.toString().toDouble()
                    resultado.text=""
                    println(valor)
                }

                 */
            }
            2->{
                operacion=2
                if(val2!=""){
                    val1=val2
                    valor1.text=val1
                    val2=""
                    valor2.text="0"
                    signo.text="/"
                }
                /*
                if(valor==0.0){
                    valor+=resultado.text.toString().toDouble()
                }else{
                    valor/=resultado.text.toString().toDouble()
                    resultado.text=""
                    println(valor)
                }

                 */
            }
            3->{
                operacion=3
                if(val2!=""){
                    val1=val2
                    valor1.text=val1
                    val2=""
                    valor2.text="0"
                    signo.text="-"
                }
                /*
                if(valor==0.0){
                    valor+=resultado.text.toString().toDouble()
                }else{
                    valor-=resultado.text.toString().toDouble()
                    resultado.text=""
                    println(valor)
                }

                 */
            }
            4->{
                operacion=4
                if(val2!=""){
                    val1=val2
                    valor1.text=val1
                    val2=""
                    valor2.text="0"
                    signo.text="+"
                }
                /*
                valor+=resultado.text.toString().toDouble()
                resultado.text=""
                println(valor)

                 */
            }
            5->{
                valor=0.0
                resultado.text=""
                valor1.text=""
                valor2.text=""
                val1=""
                val2=""
                signo.text=""
            }
            6->{
                /*println("Hasta aqui llegue amigo")
                valor2.text=valor.toString()
                println("Aqui tambien llegue amigo")
                resultado.text=""
                valor=0.0

                 */
                var num1=0.0
                var num2=0.0

                if(val1=="" || val2==""){
                    Toast.makeText( this, "Error Amigo, intenta de nuevo", Toast.LENGTH_SHORT).show()
                }else{
                    if(operacion==4){
                        num1=val1.toDouble()
                        num2=val2.toDouble()
                        valor=num1+num2
                    }
                    if(operacion==3){
                        num1=val1.toDouble()
                        num2=val2.toDouble()
                        valor=num1-num2
                    }
                    if(operacion==2){
                        if(val2.toDouble() !=0.0){
                            num1=val1.toDouble()
                            num2=val2.toDouble()
                            valor=num1/num2
                        }else{
                            Toast.makeText( this, "Error Amigo, No se puede dividir el 0 que malo eres neta", Toast.LENGTH_SHORT).show()
                        }

                    }
                    if(operacion==1){
                        num1=val1.toDouble()
                        num2=val2.toDouble()
                        valor=num1*num2
                    }
                    resultado.text=valor.toString()
                    signo.text=""
                }
            }

        }


    }

    fun num(op: Int){
        when(op){
            1->val2="$val2"+"1"
            2->val2="$val2"+"2"
            3->val2="$val2"+"3"
            4->val2="$val2"+"4"
            5->val2="$val2"+"5"
            6->val2="$val2"+"6"
            7->val2="$val2"+"7"
            8->val2="$val2"+"8"
            9->val2="$val2"+"9"
            0->val2="$val2"+"0"
        }
        valor2.setText("$val2")

    }




}
